<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Detalle Ubicacion</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  </head>
  <body>
        <?php echo e(csrf_field()); ?>

        <h1>Detalle Ubicacion</h1>          
          <div class="form-group">
           <label for="nombreUsuario">Usuario</label>
           <input type="text" class="form-control" id="nombreUsuario" name="nombreUsuario" value="<?php echo e($usuario->nombreUsuario); ?>">
          </div>
          <div class="form-group">
           <label for="descripcion">Descripcion</label>
           <input type="text" class="form-control" id="descripcion" name="descripcion" value="<?php echo e($usuario->descripcion); ?>">
          </div>         
      
      
      <div class="container">
         <div id="mapa" style="height: 400px"></div>

          <script>
                  function initMap() {
                      var pabellonV = {lat: <?php echo e($usuario->latitud); ?> , lng:<?php echo e($usuario->longitud); ?>};
             
                      var map = new google.maps.Map(document.getElementById('mapa'), {
                        zoom: 16,
                        center: pabellonV
                      });
             
                      var marker = new google.maps.Marker({
                        position: pabellonV,
                        map: map,
                        title: 'Telecom!'
                      });
                    };
                      
                  </script>
                  
                  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDlsmx6_ehv1E-L69dAcXUMrKNMTEKO3u0&callback=initMap"
                async defer></script>


      </div>
      <form action="/administradores/modify" method="GET">
        <button type="submit" class="btn btn-warning">Regresar</button>
      </form>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>  
  </body>
</html>