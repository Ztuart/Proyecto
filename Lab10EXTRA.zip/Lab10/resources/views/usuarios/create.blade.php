<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Logueado</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">
        <div class="row">
          <form action="/usuarios/store" method="POST">
            {{ csrf_field() }}
              <div class="col-md-12 col-xs-12">
                              <h1>INGRESO</h1>
                               <div class="form-group">
                                <label for="nombreUsuario">Nombre del Usuario</label>
                                <input type="text" class="form-control" id="nombreUsuario" name="nombreUsuario">
                              </div>
                              <div class="form-group">
                                <label for="descripcion">Descripcion</label>
                                <input type="text" class="form-control" id="descripcion" name="descripcion">
                              </div>
                              <div class="form-group">
                                <input type="hidden" class="form-control input-sm" id="latitud" name="latitud">
                              </div>
                              <div class="form-group">
                                <input type="hidden" class="form-control input-sm" id="longitud" name="longitud">
                              </div>

                              <div class="container">
                                      <div id="map" style="height: 400px"></div>
                                          <script>
                                            // Note: This example requires that you consent to location sharing when
                                            // prompted by your browser. If you see the error "The Geolocation service
                                            // failed.", it means you probably did not give permission for the browser to
                                            // locate you.

                                            function initMap() {
                                              var map = new google.maps.Map(document.getElementById('map'), {
                                                center: {lat: -34.397, lng: 150.644},
                                                zoom: 16
                                              });
                                              var infoWindow = new google.maps.InfoWindow({map: map});

                                              // Try HTML5 geolocation.
                                              if (navigator.geolocation) {
                                                navigator.geolocation.getCurrentPosition(function(position) {
                                                  var pos = {
                                                    lat: position.coords.latitude,
                                                    lng: position.coords.longitude
                                                  };
                                                  infoWindow.setPosition(pos);
                                                  infoWindow.setContent('Location found.');
                                                  map.setCenter(pos);
                                                  $('#latitud').val(position.coords.latitude);
                                                  $('#longitud').val(position.coords.longitude);

                                                }, function() {
                                                  handleLocationError(true, infoWindow, map.getCenter());
                                                });
                                              } else {
                                                // Browser doesn't support Geolocation
                                                handleLocationError(false, infoWindow, map.getCenter());
                                              }
                                            }

                                            function handleLocationError(browserHasGeolocation, infoWindow, pos) {
                                              infoWindow.setPosition(pos);
                                              infoWindow.setContent(browserHasGeolocation ?
                                                                    'Error: The Geolocation service failed.' :
                                                                    'Error: Your browser doesn\'t support geolocation.');
                                            }
                                          </script>
                                      <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDlsmx6_ehv1E-L69dAcXUMrKNMTEKO3u0&callback=initMap"
                                    async defer></script>
                              </div>
                          </div>

                          <button type="submit" class="btn btn-primary">
                                  <span class="glyphicon glyphicon-plus"></span>Guardar
                          </button>
          </form>
            
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>  
  </body>
</html>