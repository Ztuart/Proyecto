<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Administrador;
use App\Usuario;
class AdministradoresController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        return view('administradores.index');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request)
    {
        $usuarios = Usuario::all();
        $correo = $request->input('correo');
        $password = $request->input('password');
        $administrador = DB::table('administradors')->where([['correo', '=', $correo],['password', '=', $password],])->get();
        if($administrador == '[]'){
            return view('administradores.index', compact('administrador'));
        }else{
            $request->session()->put('correo', $correo);
            return view('administradores.modify', compact('usuarios'));
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function logout()
    {
        return view('usuarios.index');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    
}
