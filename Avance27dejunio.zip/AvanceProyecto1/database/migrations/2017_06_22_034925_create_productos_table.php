<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductosTable extends Migration
{
    public function up()
    {
        Schema::create('productos', function (Blueprint $table) {
            $table->increments('idProducto');
            $table->string('nombreProducto',100);
            $table->string('imagen',100);
            $table->integer('idCategoria')->unsigned();
            $table->date('horaInicio');
            $table->date('horaFin');
            $table->date('fechaFin');
            $table->string('zonaReparto',100); 
            $table->string('descripcion',100);
            $table->integer('idVendedor')->unsigned();
        });
    }
    public function down()
    {
        Schema::dropIfExists('productos');
    }
}
