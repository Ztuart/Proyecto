<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {

            $table->increments('id');
            $table->integer('idRol')->default('1'); //Publico1;Administrador2
            $table->string('name',50);
            $table->string('lastname',50);
            $table->string('email',50)->unique();
            $table->string('password',255);
            $table->string('alias',40);
            $table->smallInteger('estado')->default('0'); //Habilitado1; Deshabilitado0
            $table->integer('numReports')->default('0');
            $table->string('hash',256);
            $table->rememberToken();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('users');
    }
}
