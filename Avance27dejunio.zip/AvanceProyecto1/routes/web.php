<?php

//Route::get('/log/{va1}/{var2}/fox', 'TestController@metodo1');  en function(var1, var2){}
//Route::get('/log', 'TestController@metodo2');

Route::get('/', function () {
	return view('auth.login');
});
Auth::routes();

Route::get('/validarCorreo', 'EmailConfirmController@dirigirCorreo');
Route::post('/validarCorreo', 'EmailConfirmController@validarCorreo');
/*
// Authentication Routes...
$this->get('login', 'Auth\LoginController@showLoginForm')->name('login');    YA ESTA
$this->post('login', 'Auth\LoginController@login');    YA ESTA
$this->post('logout', 'Auth\LoginController@logout')->name('logout');

// Registration Routes...
$this->get('register', 'Auth\RegisterController@showRegistrationForm')->name('register');   YA ESTA
$this->post('register', 'Auth\RegisterController@register');

// Password Reset Routes...
$this->get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm');
$this->post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail');

$this->get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm');
$this->post('password/reset', 'Auth\ResetPasswordController@reset');*/

Route::get('/home', 'TestController@metodo3');
Route::get('/C/C', function () {
    return view('auth.login');
});