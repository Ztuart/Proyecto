<?php

namespace App\Http\Controllers\Products;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Categoria;

class ProductsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function crearProducto()
    {
    	$categorias = Categoria::all();	
    	return view('products.create', compact('categorias'));

    }

    public function guardarProducto(Request $request){

    	$producto = new Producto();
    	$producto->nombreProducto = $request->input('nameProd');	
    	$producto->descripcion = $request->input('description');	
     	$producto->horaInicio = $request->input('horaInicio');
      	$producto->horaFin = $request->input('horaFin');	   	    		   	
      	$producto->fechaFin = $request->input('fechaFin');

      	$latitud = $request->input('latitud');
      	$longitud = $request->input('longitud');
      	$zona = $latitud."@".$longitud;
      	$producto->zonaReparto = $zona;
      	$producto->save();

      	//obtenemos el campo file definido en el formulario
       $file = $request->file('file');
 
       //obtenemos el nombre del archivo
       $nombre = $file->getClientOriginalName();
 
       //indicamos que queremos guardar un nuevo archivo en el disco local
       \Storage::disk('local')->put($nombre,  \File::get($file));
 
       return "archivo guardado";




      	redirect('/home');



    }

}
