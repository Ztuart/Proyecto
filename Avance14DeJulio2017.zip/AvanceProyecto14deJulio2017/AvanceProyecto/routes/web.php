<?php
// Autenticatión
Auth::routes();
Route::get('/',  'Auth\LoginController@log');
Route::get('/validarCorreo', 'EmailConfirmController@dirigirCorreo');
Route::post('/validarCorreo', 'EmailConfirmController@validarCorreo');
//Panel Administrador
Route::get('/admin', 'Admin\AdminController@mainPrincipal');
Route::get('/panelAdmin', 'Admin\AdminController@panelControl');
Route::post('/panelAdmin/buscar', 'Admin\AdminController@buscarPorCorreo');
Route::get('/panelAdmin/buscar', 'Admin\AdminController@buscarReportados');
Route::get('/panelAdmin/cambiarEstado/{id}', 'Admin\AdminController@cambiarEstado');
//Panel principal
Route::get('/home', 'Home\HomeController@mainPrincipal');

//Productos
Route::get('/productos/create', 'Products\ProductsController@crearProducto');
Route::post('/productos/save', 'Products\ProductsController@guardarProducto');
















/*
// Authentication Routes...
$this->get('login', 'Auth\LoginController@showLoginForm')->name('login');    YA ESTA
$this->post('login', 'Auth\LoginController@login');    YA ESTA
$this->post('logout', 'Auth\LoginController@logout')->name('logout');

// Registration Routes...
$this->get('register', 'Auth\RegisterController@showRegistrationForm')->name('register');   YA ESTA
$this->post('register', 'Auth\RegisterController@register');

// Password Reset Routes...
$this->get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm');
$this->post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail');

$this->get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm');
$this->post('password/reset', 'Auth\ResetPasswordController@reset');*/