<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <link rel="stylesheet" href="main.css">
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	</head>
	<body>
		<div class="container">
		    <div class="row">
			<img src="https://raw.githubusercontent.com/Ztuart/Proyecto/master/149458974_1296d66e-e4ab-4740-8a20-a765c0570297.png" class="image col-md-5 col-xs-5" style="margin-top: 45px;" alt="image">
		    </div>
		    <div class="row">
		        <div class="col-md-6 col-xs-6 col-md-offset-0 col-xs-offset-0">
		            <div class="panel panel-default">
		                <div class="panel-heading">
		                	<h3><b> Registro Delivery PUCP</b></h3>  <br/>
		                </div>
		                <div class="panel-body">
		                    <h4> Hola, <?php echo e($nombre); ?>!</h4>  <br/>
		                    <h4> Ingresa al siguente link para completar el registro!</h4>  <br/>
		                    <a href="http://127.0.0.1:8000/validarCorreo/?acc=<?php echo e($hash); ?>">Siga el link para confirmar su correo</a>
		                </div>
		            </div>
		        </div>

		    </div>
		</div>

	</body>
</html>
