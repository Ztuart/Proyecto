<!--MockUp Generar Producto a vender-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Indique locaclización</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
      <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <style type="text/css">

          
          .relleno{
            margin-bottom: 20px;
          }
          .borde{
            border-style: solid;
          }
          .bordeado{
            border-style: ridge;
            border-radius: 12px 12px 12px 12px;
            border: 1px solid #000000;
          }
          .jumbotron{
            margin-top: 20px;
            background-color: #DAB4AB;
          
    </style>


  </head>
  <body>
      <div class="container">
        <form action="/productos/{{$producto->idProducto}}/finalizarCompra" method="POST">
            <input type="hidden" name="_token" value="{{ csrf_token() }}">
            <div class="jumbotron">
                      <div class="row">
                          <div class="col-md-12 relleno">
                              <h1>El producto escogido es: {{$producto->nombreProducto}}</h1>
                              <b><label>Para que el vendedor pueda ubicarlo es necesario que brinde su localización mediante ambas formas:</label></b> 
                          </div>
                      </div>
                      <div class="row">
                          <div class="col-md-6 relleno">     
                                <b><label>UBICACIÓN</label></b>
                                <br>
                                <div id="mapas" class="control-label col-sm-12" style="height:215px"></div>
                                <input type="hidden" class="form-control" id="latitud"  name="latitud" >
                                <input type="hidden" class="form-control" id="longitud"  name="longitud" >
                          </div>
                          <div class="col-md-6 relleno">
                                        <b><label>BREVE DESCRIPCIÓN</label></b> 
                                        <textarea type="text" rows="10" class="form-control" name="description" id="description" placeholder="Describa su localización"></textarea>
                          </div>
                      </div>
                      <div class="row">
                          <div class="col-md-12 relleno" align="center">
                              <button type="submit" class="btn btn-primary btn-lg">Aceptar</button>
                          </div>
                      </div>
            </div>
        </form>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB40mKSFkIaqRI1xpZh-Z-myVr11Lhzysk&callback=initMap"
                  async defer></script>
        <script>
              var miPos;
              var marker;
              function initMap() {
                  navigator.geolocation.getCurrentPosition(
                    function (position){
                      miPos =  {
                      lng: position.coords.longitude,
                      lat: position.coords.latitude
                      };
                    var mapa = new google.maps.Map(document.getElementById('mapas'), {
                      zoom: 10,
                      center: miPos
                    });       
                  //  var image = 'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png';            
                    marker = new google.maps.Marker({
                      position: miPos,
                      map: mapa,
                      draggable:true,
                      title:"Aquí estoy!",
                    //  icon: image
                    });
                    $('#latitud').val(marker.getPosition().lat());
                    $('#longitud').val(marker.getPosition().lng());
                    marker.addListener('dragend', eventDis);
                  },null);
              };
              function eventDis() {
                    document.getElementById("latitud").value = marker.getPosition().lat();
                    document.getElementById("longitud").value = marker.getPosition().lng();
              }
        </script>
      </div>
          
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

  </body>
</html>