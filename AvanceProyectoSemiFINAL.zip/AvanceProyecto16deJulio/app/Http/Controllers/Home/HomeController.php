<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Mail\correoValoracion;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Categoria;
use App\Producto;
use App\Orden;
use App\User;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function mainPrincipal()
    {
    	$categorias = Categoria::all();
        $productos = Producto::where('visibilidad','=',1)->paginate(4);
    	return view('home.main', compact('categorias','productos'));
    }
    
    public function mainPrincipalCategorias($id)
    {
        $categorias = Categoria::all();
        $productos = Producto::where([['visibilidad', '=', 1],['idCategoria','=',$id]])->paginate(4);
        return view('home.main', compact('categorias','productos'));
    }

    public function verMisProductos(Request $request)
    {
    	$miID = $request->session()->get('id');
    	$misproductos = DB::table('productos')->where('idVendedor', '=', $miID)->get();
    	return view('home.misproductos', compact('misproductos'));
    }
    public function visibilidadProductos($idProducto)
    {
    	$producto = Producto::find($idProducto);
        $producto->visibilidad = $producto->visibilidad == 1?0:1;
    	$producto->save();
    	return redirect('/misProductos');
    }

    public function verMisClientes(Request $request)
    {
        $miID = $request->session()->get('id');

        $idProductos = DB::table('productos')->where('idVendedor', $miID)->pluck('idProducto');

        $misclientes = DB::table('ordens')->join('users','ordens.idComprador','=','users.id')->whereIn('ordens.idProducto', $idProductos)->orderBy('ordens.idOrden', 'asc')->select('ordens.idOrden','ordens.latitud', 'ordens.longitud', 'ordens.descripcionZona','users.name','users.lastname')->get();
        return view('home.misclientes', compact('misclientes'));
    }

    public function borrarClientes(Request $request,$idOrden)
    {
        $idVendedor = $request->session()->get('id');

        $orden = Orden::find($idOrden);
        $cliente = User::find($orden->idComprador);
        $correoCliente = $cliente->email;
        $nombreCliente = $cliente->name;
        $vendedor = User::find($idVendedor);
        $hashVendedor = $vendedor->hash;
     //   $hash = $cliente->hash;
        Mail::to($correoCliente)->send(new correoValoracion($nombreCliente,$hashVendedor));
        $orden->delete();
        return redirect('/misClientes');
    }


}
