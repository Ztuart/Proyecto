<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;

class EmailConfirmController extends Controller
{
    public function dirigirCorreo()
    {
    	$val = $_GET['acc'];
        return view('emails.confirm', compact('val'));
    }
    public function validarCorreo(Request $request)
    {
        $hash = $request->input('val');
        $user =DB::table('users')->where('hash', '=', $hash)->first();
        if(is_null($user)){

        } else {
            DB::table('users')->where('hash', $hash)->update(['estado' => 1]);
        }
        return redirect('/');
    }

    public function dirigirCorreo2()
    {
        $val = $_GET['acc'];
        return view('emails.reportarVendedor', compact('val'));
    }
    public function reportarVendedor(Request $request)
    {
        $hash = $request->input('val');
        $vendedor =DB::table('users')->where('hash', '=', $hash)->first();
        if(is_null($vendedor)){
        }else{
            $numReportes = $vendedor->numReports;
            if($numReportes < 10){
                DB::table('users')->where('hash', $hash)->update(['numReports' => $numReportes + 1]);
            }
        }
        return redirect('/');
    }

}

