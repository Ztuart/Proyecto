
<?php
//Sesiones en PHP
//$request->session()->put('correo', $user->email);
//$request->session()->put('id', $user->id);
//$request->session()->put('idRol', $user->idRol);
// Autenticatión
Auth::routes();
Route::get('/',  'Auth\LoginController@log');
Route::get('/validarCorreo', 'EmailConfirmController@dirigirCorreo');
Route::post('/validarCorreo', 'EmailConfirmController@validarCorreo');
//Panel Administrador
Route::get('/admin', 'Admin\AdminController@mainPrincipal');
Route::get('/panelAdmin', 'Admin\AdminController@panelControl');
Route::post('/panelAdmin/buscar', 'Admin\AdminController@buscarPorCorreo');
Route::get('/panelAdmin/buscar', 'Admin\AdminController@buscarReportados');
Route::get('/panelAdmin/cambiarEstado/{id}', 'Admin\AdminController@cambiarEstado');
//Panel principal
Route::get('/home', 'Home\HomeController@mainPrincipal');
Route::get('/home/{idCategoria}', 'Home\HomeController@mainPrincipalCategorias');
Route::get('/misProductos', 'Home\HomeController@verMisProductos');
Route::get('/misProductos/visibilidad/{idProducto}', 'Home\HomeController@visibilidadProductos');

//Editar Mi Info
Route::get('/info', 'Auth\MyInfoController@mostrarFormInfo');
Route::post('/info', 'Auth\MyInfoController@saveNewInfo');

//Productos CRUD
Route::get('/productos/create', 'Products\ProductsController@crearProducto');
Route::post('/productos/save', 'Products\ProductsController@guardarProducto');
Route::get('/productos/{idProducto}','Products\ProductsController@verProducto' );
Route::post('/guardarMensaje','Products\ProductsController@guardarMensaje');

Route::get('/productos/{idProducto}/edit','Products\ProductsController@formEdit' );
Route::post('/productos/{idProducto}/save','Products\ProductsController@saveEdit' );

Route::get('/productos/{idProducto}/comprar','Products\ProductsController@establecerLocalizacion');
Route::post('/productos/{idProducto}/finalizarCompra','Products\ProductsController@finalizarCompra' );

//Clientes
Route::get('/misClientes', 'Home\HomeController@verMisClientes');
Route::get('/home/{idOrden}/borrar', 'Home\HomeController@borrarClientes');


//Reportar
Route::get('/valorar', 'EmailConfirmController@dirigirCorreo2');
Route::post('/valorar', 'EmailConfirmController@reportarVendedor');










/*
// Authentication Routes...
$this->get('login', 'Auth\LoginController@showLoginForm')->name('login');    YA ESTA
$this->post('login', 'Auth\LoginController@login');    YA ESTA
$this->post('logout', 'Auth\LoginController@logout')->name('logout');

// Registration Routes...
$this->get('register', 'Auth\RegisterController@showRegistrationForm')->name('register');   YA ESTA
$this->post('register', 'Auth\RegisterController@register');

// Password Reset Routes...
$this->get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm');
$this->post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail');

$this->get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm');
$this->post('password/reset', 'Auth\ResetPasswordController@reset');*/