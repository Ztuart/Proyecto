<!DOCTYPE html>
<html lang="en">
  <head>
          <meta charset="utf-8">
          <meta http-equiv="X-UA-Compatible" content="IE=edge">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <title>Lista de Clientes</title>

          <!-- Bootstrap -->
          <link href="css/bootstrap.min.css" rel="stylesheet">
            <!-- Latest compiled and minified CSS -->
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">

          <!-- Latest compiled and minified JavaScript -->
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

          <style type="text/css">

               .borde{
                  border-style: groove;
                  border-radius: 10px;
               }
               .jumbotron{
                  min-width: 440px;
                  padding-top: 30px;
                  margin-top: 20px;
                  padding-left: 80px;
                  padding-right: 80px;
                  background-color: rgb(228,210,143); 
               }
               #boton{
                  margin-top: 15px;
               }
               #regresar{
                  min-width: 150px;
                  box-shadow: rgb(154, 204, 133) 0px 0px 0px 0px inset;
                  background: linear-gradient(rgb(116, 173, 90) 5%, rgb(104, 165, 75) 100%) rgb(116, 173, 90);
                  border-radius: 10px; 
                  border: 1px solid rgb(59, 110, 34); 
                  display: inline-block; 
                  cursor: pointer; 
                  color: rgb(255, 255, 255); 
                  font-family: Arial; font-size: 20px; 
                  font-weight: bold; 
                  padding: 12px 27px; 
               
               }
               h2{
                  text-decoration: underline;
               }

          </style>



  </head>
  <body>
      <div class="container">
          <div class="col-md-12 col-xs-12"> 
              <h3>PUCP Delivery</h3>
          </div>        
          <div class="jumbotron">
              <div class="row">  
                  <h1 class="col-md-10">Lista de Clientes:</h1>
                  <a id ="regresar" class="btn btn-success col-md-1" href="/home" role="button">Regresar</a>
                  
              </div>
              <br> 
              <?php $__currentLoopData = $misclientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="borde">
                    <div class="row">             
                          <div class="col-md-4 col-xs-4">
                                <div id="mapas" class="control-label col-md-12" width="50px" height="50px"></div>
                                <script>
                                        var miPos;
                                        var marker;
                                        function initMap() {
                                              navigator.geolocation.getCurrentPosition(
                                                  function (position){
                                                              miPos =  {
                                                              lng: <?php echo e($cliente->longitud); ?>,
                                                              lat: <?php echo e($cliente->latitud); ?>

                                                              };
                                                            var mapa = new google.maps.Map(document.getElementById('mapas'), {
                                                              zoom: 10,
                                                              center: miPos
                                                            });       
                                                                 
                                                            marker = new google.maps.Marker({
                                                              position: miPos,
                                                              map: mapa,
                                                              title:"Aquí se encuentra tu cliente!",
                                                            }); 
                                                  },null);
                                        };
                                </script>
                          </div>                    
                          <div class="col-md-4 col-xs-4">
                            <h2><?php echo e($cliente->name.' '.$cliente->lastname); ?></h2>
                                <p><?php echo e($cliente->descripcionZona); ?></p>
                          </div> 
                          <div class="col-md-4">
                              <a id="boton" class="btn btn-primary col-md-9" href="/home/<?php echo e($cliente->idOrden); ?>/borrar" role="button">Finalizar</a><br>
                          </div>                                          
                    </div>
              </div>
              <br>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB40mKSFkIaqRI1xpZh-Z-myVr11Lhzysk&callback=initMap" async defer>
        </script>
        


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
 
  </body>
</html>