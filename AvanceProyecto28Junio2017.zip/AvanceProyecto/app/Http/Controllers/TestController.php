<?php

namespace App\Http\Controllers;

class TestController extends Controller
{
	public function __construct()
    {
    	//se pone en el constructor auth
    	//solo para que puedan acceder los que estén autenticados
    	//para el uso de controladores
        $this->middleware('auth');
    }
    public function metodo3()
    {
    	return view('users.home');
    }
    public function metodo1($v1, $v2)
    {
    	return sha1($v1."----".$v2);
    }
    public function metodo2()
    {
    	return $_GET['id']."-----". $_GET['pass'];
    }
}
