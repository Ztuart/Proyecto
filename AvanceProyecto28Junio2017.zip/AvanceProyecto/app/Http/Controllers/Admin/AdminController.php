<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function mainPrincipal(){
    	return view('admin.main');
    }

    public function panelControl(){
    	$usuarios = User::all();
    	return view('admin.control', compact('usuarios'));
    }

     public function buscarPorCorreo(Request $request){
     		$correo = $request->input('email');
			$usuarios = DB::table('users')->where([['email','=',$correo]])->get();
    	return view('admin.control', compact('usuarios'));
     }

     public function buscarReportados(){
			$usuarios = DB::table('users')->where([['numReports','>', 0]])->get();
    	return view('admin.control', compact('usuarios'));
     }

     public function cambiarEstado($id){
     		$usuario = User::FindOrFail($id);
     		if($usuario->estado == 1){
     			$usuarios = DB::table('users')->where('id',$id)->update(['estado'=>0]);
     		}else{
     			$usuarios = DB::table('users')->where('id',$id)->update(['estado'=>1]);
     		}
    	return redirect('/panelAdmin');
     }



}
