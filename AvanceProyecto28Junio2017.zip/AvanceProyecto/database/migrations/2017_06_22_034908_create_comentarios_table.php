<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateComentariosTable extends Migration
{
    public function up()
    {
        Schema::create('comentarios', function (Blueprint $table) {

            $table->increments('idComentario');
            $table->string('comentario',100); 
            $table->integer('idProducto')->unsigned();
            $table->integer('idComentarioPadre')->unsigned();
        });
    }
    public function down()
    {
        Schema::dropIfExists('comentarios');
    }
}
