<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateValoracionsTable extends Migration
{
    public function up()
    {
        Schema::create('valoracions', function (Blueprint $table) {
            $table->increments('idValoracion');
            $table->float('puntaje');
        });
    }
    public function down()
    {
        Schema::dropIfExists('valoracions');
    }
}
