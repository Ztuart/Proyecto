<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdensTable extends Migration
{
    public function up()
    {
        Schema::create('ordens', function (Blueprint $table) {

            $table->increments('idOrden');
            $table->double('latitud');
            $table->double('longitud');
            $table->integer('idValoracion')->unsigned();
            $table->integer('idProducto')->unsigned();
            $table->string('descripcionZona', 100);
            $table->integer('idComprador')->unsigned();
        });
    }
    public function down()
    {
        Schema::dropIfExists('ordens');
    }
}
