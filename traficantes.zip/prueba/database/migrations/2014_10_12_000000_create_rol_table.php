<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
class CreateRolTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('rol', function (Blueprint $table) {
            
            $table->increments('idRol');
            $table->string('rol');
        });

        DB::table('rol')->insert(
            array(
                'idRol' => '1',
                'rol' => 'publico'
            )
        );

        DB::table('rol')->insert(
            array(
                'idRol' => '2',
                'rol' => 'administrador'
            )
        );
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('rol');
    }
}
