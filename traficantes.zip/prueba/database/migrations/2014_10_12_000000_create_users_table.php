<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            
            $table->increments('id');
            $table->integer('idRol')->unsigned()->default('1'); //Publico1;Administrador2
            $table->string('name');
            $table->string('lastname');
            $table->string('email')->unique();
            $table->string('password');
            $table->string('alias');
            $table->smallInteger('estado')->default('1'); //Habilitado1; Deshabilitado2
            $table->integer('numReports')->default('0');
            $table->rememberToken()->default($table->string('email'));
            $table->timestamps();
        });

        Schema::table('users', function($table) {
           $table->foreign('idRol')->references('idRol')->on('rol');
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
