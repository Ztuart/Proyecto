<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
           
        <link rel="stylesheet" href="main.css">
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	</head>
	<body>
		<div class="container">
			<img src="https://raw.githubusercontent.com/Ztuart/Proyecto/master/149458974_1296d66e-e4ab-4740-8a20-a765c0570297.png" class="image col-md-5 col-xs-5" style="
    margin-top: 25px;" alt="image">
		    <div class="row">
		        <div class="col-md-6 col-xs-6 col-md-offset-4 col-xs-offset-4">
		            <div class="panel panel-default">
		                <div class="panel-heading">Enlace</div>
		                <div class="panel-body">
		                    mi nombre es: <?php echo e($nombre); ?>

		                </div>
		                <form action="C/C" method="GET">
		                    <button type="submit" class="btn btn-primary">Entrar a la aplicación</button>
		                </form>
		            </div>
		        </div>
		    </div>
		</div>
	</body>
</html>