<?php

namespace App\Http\Controllers\Products;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Categoria;
use App\Producto;

class ProductsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function crearProducto()
    {
    	$categorias = Categoria::all();	
    	return view('products.create', compact('categorias'));
    }

    public function guardarProducto(Request $request)
    {
      
      

    	$producto = new Producto();
    	$producto->nombreProducto = $request->input('nameProd');
    	$producto->descripcion = $request->input('description');

     	$producto->horaInicio = date('h:i A',strtotime($request->input('horaInicio')));
    	$producto->horaFin = date('h:i A',strtotime($request->input('horaFin')));  		   	
    	$producto->fechaFin = $request->input('fechaFin');
      $producto->idCategoria = $request->input('idCategoria');
      $producto->latitud = $request->input('latitud');
      $producto->longitud = $request->input('longitud');

      $producto->idVendedor = $request->session()->get('id');

      if($request->hasFile('image')){
            $producto->imagen = Storage::putFile('public', $request->file('image'));
      }else{
            $producto->imagen = "imagenPorDefecto.png";
      }

      $producto->save();
     	return redirect('/home');
    }

}
