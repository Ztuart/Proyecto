<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use App\Categoria;
use App\Producto;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function mainPrincipal(){
    	$categorias = Categoria::all();
    	$productos = Producto::paginate(1);


    	$producto = Producto::first();
    	$pro = $producto->imagen;
    	$file = Storage::disk('local')->get('kOu4PlwS5qCi9FZesZS33JIPKUMBUWJKbM9klfjS.jpeg');
    	return new Response($file,200);
    	//return "<img src='".$url."'/>";
    	//return view('home.main', compact('categorias','productos'));
    }

}
