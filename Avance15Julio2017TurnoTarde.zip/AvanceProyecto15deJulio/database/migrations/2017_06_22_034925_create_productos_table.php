<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductosTable extends Migration
{
    public function up()
    {
        Schema::create('productos', function (Blueprint $table) {
            $table->increments('idProducto');
            $table->string('nombreProducto',200);
            $table->string('imagen',200);
            $table->integer('idCategoria')->unsigned();
            $table->string('horaInicio');
            $table->string('horaFin');
            $table->date('fechaFin');
            $table->double('latitud'); 
            $table->double('longitud'); 
            $table->string('descripcion',400);
            $table->integer('idVendedor')->unsigned();
        });
    }
    public function down()
    {
        Schema::dropIfExists('productos');
    }
}
