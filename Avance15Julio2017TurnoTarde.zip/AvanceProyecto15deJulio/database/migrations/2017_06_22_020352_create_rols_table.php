<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRolsTable extends Migration
{
    public function up()
    {
        Schema::create('rols', function (Blueprint $table) {
            $table->integer('idRol');
            $table->primary('idRol');
            $table->string('rol',13);
        });

        DB::table('rols')->insert(
            array(
                'idRol' => '1',
                'rol' => 'publico'
            )
        );

        DB::table('rols')->insert(
            array(
                'idRol' => '2',
                'rol' => 'administrador'
            )
        );
    }
    public function down()
    {
        Schema::dropIfExists('rols');
    }
}
