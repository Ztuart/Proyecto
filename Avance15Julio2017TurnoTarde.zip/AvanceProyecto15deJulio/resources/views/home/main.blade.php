@extends('layouts.app')

@section('content')
    <link rel="stylesheet"  type="text/css" href="{{asset('css/main.css')}}">
    <div class="container">
        
        <div class="jumbotron col-xs-12 col-md-12" style="border-style: ridge; padding-top:15px;padding-bottom:15px; ">
            <div class="form-group">
                <h2 class="col-xs-12 col-md-12" style="margin-top: 0px;padding-left: 0px;">Bienvenido:</h2>
            </div>
            <div class="input-group" id="adv-search">
                <input type="text" class="form-control" placeholder="Buscar Producto">
                <div class="input-group-btn">
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-primary"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
                    </div>
                </div>
            </div>
        </div>





        <div class="row col-xs-12 col-md-12">
            <div class="col-md-2 col-xs-2 sidebar">
              <h3>Categorias</h3>
              <ul class="botones">
                <?php   foreach ($categorias as $var) {  ?>
                <a href="#"><li>{{$var->nombreCategoria}}</li></a>
               <?php } ?>
              </ul>
              <br>
              <h3>Acciones</h3>
              <ul class="botones">
                <a href="/productos/create"><li>Generar Producto</li></a>
                <a href="/productos"><li>Mis productos</li></a>
                <a href="/info"><li>Editar mi info</li></a>
                <a href="#"><li>Mis clientes</li></a>
              </ul>

            </div>


        @foreach($productos as $producto)
        <div class="col-md-offset-2 col-xs-offset-2 col-md-8 col-xs-8 panel panel-default">
          <div class="panel-body">
            <div class="col-md-4 ">
                <img src="{{$producto->imagen}}" class="image media-object" alt="image" width="150px" height="120px">
            </div>
              <div class="col-md-6 ">
                <h2>{{$producto->nombreProducto}}</h2>
                    <p>{{$producto->descripcion}}</p>
              </div>
            <div><a class="btn btn-primary col-md-2" href="detalleProducto.html" role="button">Comprar</a><br></div><br>
          </div>
        </div>
        @endforeach
         <div class="col-md-offset-2 col-xs-offset-2 col-md-8 col-xs-8">{{$productos->render()}}
         </div>

      </div>
            
            
        
    </div>
@endsection
