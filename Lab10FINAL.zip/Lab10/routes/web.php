<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/usuarios/create', 'UsuariosController@create');
Route::get('/', 'UsuariosController@index');

Route::get('/usuarios/index', function () {
    return view('usuarios.index');
});

Route::get('/administradores/index', 'AdministradoresController@index');
Route::post('/usuarios/store', 'UsuariosController@store');
Route::post('/usuarios/destroy', 'UsuariosController@borrar');
Route::post('/usuarios/show/{{$usuario->id}}', 'UsuariosController@show');

Route::post('/administradores/modify', 'AdministradoresController@login');