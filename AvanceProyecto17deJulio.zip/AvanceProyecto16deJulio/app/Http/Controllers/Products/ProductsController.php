<?php

namespace App\Http\Controllers\Products;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Categoria;
use App\Producto;
use App\User;
use App\Orden;

class ProductsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function crearProducto()
    {
    	$categorias = Categoria::all();	
    	return view('products.create', compact('categorias'));
    }

    public function guardarProducto(Request $request)
    {
    	$producto = new Producto();
    	$producto->nombreProducto = $request->input('nameProd');
    	$producto->descripcion = $request->input('description');

     	$producto->horaInicio = $request->input('horaInicio');
    	$producto->horaFin = $request->input('horaFin');  		   	
    	$producto->fechaFin = $request->input('fechaFin');
      $producto->idCategoria = $request->input('idCategoria');
      $producto->latitud = $request->input('latitud');
      $producto->longitud = $request->input('longitud');

      $producto->idVendedor = $request->session()->get('id');

      if($request->hasFile('image')){
            $producto->imagen = Storage::putFile('public', $request->file('image'));
      }

      $producto->save();
     	return redirect('/home');
    }
    public function verProducto($id)
    {
      $producto = Producto::find($id);
      $vendedor = User::find($producto->idVendedor);
      $listComents = DB::table('comentarios')->join('users', function ($join) use ($id) {
          $join->on('users.id', '=', 'comentarios.idPersona')
          ->where('comentarios.idProducto', '=', $id);
          })->get();
      return view('home.detalleProducto', compact('producto', 'vendedor','listComents'));
    }
    public function guardarMensaje(Request $request)
    {
      $idpro= $request->input('idProducto');
      DB::table('comentarios')->insert(
      array(
      'comentario' => $request->input('comment'),
      'idProducto' => $request->input('idProducto'),
      'idPersona' => $request->session()->get('id')                 
      )
      );     
      return redirect('/productos/'.$idpro);
    }
    public function formEdit($id)
    {
      $producto = Producto::find($id);
      $categorias = Categoria::all(); 
      return view('products.edit', compact('producto','categorias'));
    }

    public function saveEdit(Request $request, $idProducto)
    {
      $producto = Producto::find($idProducto);
      $producto->nombreProducto = $request->input('nameProd');
      $producto->descripcion = $request->input('description');
      $producto->horaInicio = $request->input('horaInicio');
      $producto->horaFin = $request->input('horaFin');          
      $producto->fechaFin = $request->input('fechaFin');
      $producto->idCategoria = $request->input('idCategoria');
      $producto->latitud = $request->input('latitud');
      $producto->longitud = $request->input('longitud');
      $producto->idVendedor = $request->session()->get('id');
      $producto->save();
      return redirect('/home');
    }

    public function establecerLocalizacion($idProducto)
    {
      $producto = Producto::find($idProducto);
      return view('products.find', compact('producto'));
    }

    public function finalizarCompra(Request $request, $idProducto)
    {
      $orden = new Orden();
      $orden->idComprador = $request->session()->get('id');
      $orden->descripcionZona = $request->input('description');
      $orden->latitud = $request->input('latitud');
      $orden->longitud = $request->input('longitud');
     //FALTA DEFINIR LA TABLA $orden->idValoracion = null;
      $orden->idProducto = $idProducto;
      $orden->save();
      return redirect('/home');
    }

}
