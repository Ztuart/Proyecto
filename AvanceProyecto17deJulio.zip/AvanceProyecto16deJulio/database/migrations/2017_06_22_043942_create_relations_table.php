<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

class CreateRelationsTable extends Migration
{
    public function up()
    {
        Schema::table('users', function ($table) {
            $table->foreign('idRol')->references('idRol')->on('rols');
        });
        Schema::table('productos', function ($table) {
            $table->foreign('idVendedor')->references('id')->on('users');
        });
        Schema::table('productos', function ($table) {
            $table->foreign('idCategoria')->references('idCategoria')->on('categorias');
        });
        Schema::table('comentarios', function ($table) {
            $table->foreign('idProducto')->references('idProducto')->on('productos');
        });
     /*   Schema::table('comentarios', function ($table) {
            $table->foreign('idComentarioPadre')->references('idComentario')->on('comentarios');
        });         */       
        Schema::table('ordens', function ($table) {
            $table->foreign('idProducto')->references('idProducto')->on('productos');
        });        
        Schema::table('ordens', function ($table) {
            $table->foreign('idValoracion')->references('idValoracion')->on('valoracions');
        });                      
    }
    public function down()
    {
        //
    }
}
