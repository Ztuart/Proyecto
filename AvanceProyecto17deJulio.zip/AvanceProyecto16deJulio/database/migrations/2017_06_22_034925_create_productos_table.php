<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductosTable extends Migration
{
    public function up()
    {
        Schema::create('productos', function (Blueprint $table) {
            $table->increments('idProducto');
            $table->string('nombreProducto',200);
            $table->integer('visibilidad')->default('1');
            $table->string('imagen',200);
            $table->integer('idCategoria')->unsigned();
            $table->time('horaInicio');
            $table->time('horaFin');
            $table->date('fechaFin');
            $table->double('latitud'); 
            $table->double('longitud'); 
            $table->string('descripcion',400);
            $table->integer('idVendedor')->unsigned();
        });
        DB::table('productos')->insert(
            array(
                'nombreProducto' => 'Auto Nuevo Porshe',
                'imagen' => 'public/auto.png',
                'idCategoria' => 9,
                'horaInicio' => '12:32',   
                'horaFin' => '16:03',
                'fechaFin' => date('y:m:d',strtotime('2017-07-29')),
                'latitud' => -12.070671948153356,         
                'longitud' => -77.07954419697262,
                'descripcion' => 'precio base 100, 000 dolares',         
                'idVendedor' => 1                                      
            )
        );        
        DB::table('productos')->insert(
            array(
                'nombreProducto' => 'Departamento en alquiler',
                'imagen' => 'public/casa.jpeg',
                'idCategoria' => 2,
                'horaInicio' => '12:32',   
                'horaFin' => '16:03',
                'fechaFin' => date('y:m:d',strtotime('2017-07-29')),
                'latitud' => -12.070671948153356,         
                'longitud' => -77.07954419697262,
                'descripcion' => '3 habitaciones, todo amoblado',         
                'idVendedor' => 1                                      
            )
        );       
        DB::table('productos')->insert(
            array(
                'nombreProducto' => 'Pan Con Pollo',
                'imagen' => 'public/pan.jpeg',
                'idCategoria' => 1,
                'horaInicio' => '12:32',   
                'horaFin' => '16:03',
                'fechaFin' => date('y:m:d',strtotime('2017-07-29')),
                'latitud' => -12.070671948153356,         
                'longitud' => -77.07954419697262,
                'descripcion' => 'con su cafecito',         
                'idVendedor' => 1                                      
            )
        );       
        DB::table('productos')->insert(
            array(
                'nombreProducto' => 'CPU Intel Core i5',
                'imagen' => 'public/cpu.jpeg',
                'idCategoria' => 10,
                'horaInicio' => '12:32',   
                'horaFin' => '16:03',
                'fechaFin' => date('y:m:d',strtotime('2017-07-29')),
                'latitud' => -12.070671948153356,         
                'longitud' => -77.07954419697262,
                'descripcion' => '2 años de garantia',         
                'idVendedor' => 2                                      
            )
        );       
        DB::table('productos')->insert(
            array(
                'nombreProducto' => 'Pan Con Pollo2',
                'imagen' => 'public/pan.jpeg',
                'idCategoria' => 1,
                'horaInicio' => '12:32',   
                'horaFin' => '16:03',
                'fechaFin' => date('y:m:d',strtotime('2017-07-29')),
                'latitud' => -12.070671948153356,         
                'longitud' => -77.07954419697262,
                'descripcion' => 'con su cafecito',         
                'idVendedor' => 2                                      
            )
        );       
                                                               
    }
    public function down()
    {
        Schema::dropIfExists('productos');
    }
}
