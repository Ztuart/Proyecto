<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <div class="col-md-6 col-xs-6 col-md-offset-5 col-xs-offset-5">
  	  	<h4>Confirmar Correo de delivery PUCP</h4>
  		<form action="/validarCorreo" method="POST">
  		 <input type="hidden" name="val" value="<?php echo e($val); ?>">
  		 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    	 <button type="submit" class="btn btn-default">Activar Cuenta!</button>
  		</form>
  </div>
</div>

</body>
</html>