<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Editar Producto</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
      <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
      <div class="container">
        <form action="/productos/<?php echo e($producto->idProducto); ?>/save" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

        <div class="row">
            <div class="col-md-12">
                <div class="jumbotron"> 
                      <div class="row">
                            <div class="col-md-6">
                              <h1>Editar Producto</h1> 
                            </div>
                            <div class="col-md-6">
                              <button type="submit" id="registrar" class="btn btn-success btn-lg">Guardar</button>
                            </div>
                      </div>

                </div>
            </div>
        </div>
        <div class="row">

            <div class="col-md-6">
                  <div class="jumbotron">
                          <b><label>Nombre del Producto:</label></b> 
                          <input type="text" class="form-control" name = "nameProd" id="nameProd" value="<?php echo e($producto->nombreProducto); ?>">      

                          <b><label>Descripción del Producto: </label> </b>
                          <textarea type="text" rows="4" class="form-control" name="description" id="description" ><?php echo e($producto->descripcion); ?></textarea>                                 

                          <b><label>Categorias:</label></b> 
                          <select name="idCategoria" id="idCategoria" class="form-control">
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categoria->idCategoria); ?>" <?php echo e($producto->idCategoria==$categoria->idCategoria?"selected":" "); ?>><?php echo e($categoria->nombreCategoria); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          


                          <b><label>Hora inicio: </label></b>                 
                          <input type="time" class="form-control" name = "horaInicio" id="horaInicio" value="<?php echo e($producto->horaInicio); ?>">

                          <b><label>Hora fin: </label></b>
                          <input type="time" class="form-control" name = "horaFin" id="horaFin" value="<?php echo e($producto->horaFin); ?>">
                                        
                          <b><label>Fecha fin: </label></b> 
                          <div id="fecha" class="form-control">        
                            <input type="date" class="form-control col-md-10" name="fechaFin" id="fechaFin" value="<?php echo e($producto->fechaFin); ?>">
                          </div><br>                   
                          
                  </div>   
            </div>
            <div class="col-md-6">     
                  <div class="jumbotron">                 
                  <b><label>EDITAR UBICACION</label></b>
                  <br>
                      <div id="mapas" class="control-label col-sm-12" style="height:488px"></div>
                      <input type="hidden" class="form-control" id="latitud"  name="latitud" >
                      <input type="hidden" class="form-control" id="longitud"  name="longitud" >
                  </div>
                
            </div>
        </div>
    </form>
                  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB40mKSFkIaqRI1xpZh-Z-myVr11Lhzysk&callback=initMap"
                  async defer></script>
                          <script>
                          var miPos;
                          var marker;
                          function initMap() {
                              navigator.geolocation.getCurrentPosition(
                                function (position){
                                  miPos =  {
                                  lng: <?php echo e($producto->longitud); ?>,
                                  lat: <?php echo e($producto->latitud); ?>

                                  };
                                var mapa = new google.maps.Map(document.getElementById('mapas'), {
                                  zoom: 14,
                                  center: miPos
                                });       
                              //  var image = 'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png';            
                                marker = new google.maps.Marker({
                                  position: miPos,
                                  map: mapa,
                                  draggable:true,
                                  title:"Aquí estoy :D !",
                                //  icon: image
                                }); 
                                $('#latitud').val(marker.getPosition().lat());
                                $('#longitud').val(marker.getPosition().lng());
                                marker.addListener('dragend', eventDis);
                              },null);
                          };
                          function eventDis() {
                                document.getElementById("latitud").value = marker.getPosition().lat();
                                document.getElementById("longitud").value = marker.getPosition().lng();
                          }
                          </script>
        </div>
          
        <style type="text/css">
            .jumbotron{
              background-color:#DD9471; 
              padding-top: 10px;
              padding-bottom: 30px;
            }
            #registrar{
                padding-top: 12px;
                float: right;
            }

            
            #botonFile{
                color:#8F0B14;
            }

            html body{
                  background-image: url("https://image.freepik.com/vector-gratis/fondo-con-elementos-de-estilo-memphis_1017-7011.jpg"); 
                  
            }
        </style>
    

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

  </body>
</html>