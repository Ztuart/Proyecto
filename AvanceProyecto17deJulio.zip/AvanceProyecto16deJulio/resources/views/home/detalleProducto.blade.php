<!--MockUp Generar Producto a vender-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Detalle del Producto</title>

      <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <style type="text/css">

          #editar{
            font-size: 1.5em;
            
          }
          .imag{
            min-width: 400px;
          }

          .relleno{
            margin-top: 30px;
          }
          .borde{
            border-style: solid;
          }
          .bordeado{
            border-style: ridge;
            border-radius: 12px 12px 12px 12px;
            border: 1px solid #000000;
          }
          .jumbotron{
            background-color: #ecb535 ;
          }
          html body{
            background-image: url("http://dissenyaweb.com/blog/diseno_web/wp-content/uploads/christian-background-loops.jpg");
          }
    </style>


  </head>
  <body >
      <div class="container imag">
      <br>
        <div class="jumbotron">
          <div class="row col-md-12 col-xs-12">
              <div class="col-md-7 col-xs-7 titulo">
                  <h1>{{$producto->nombreProducto}}</h1> 
              </div>
              <div class="col-md-5 col-xs-5">
                  <button id="editar" class="btn btn-success" onclick="confirmar()">Realizar Compra</button> 
              </div>
          </div>
          <br>
          <div class="row col-md-12 col-xs-12">
                  <div class="col-md-4 col-xs-4">
                        <img src="{{'/storage/'.$producto->imagen}}" class="image media-object" width="290" height="250">
                  </div>
                  <div class="col-md-3 col-xs-3">
                      <h5>Vendedor:<h5>
                      <h2>{{$vendedor->name.' '.$vendedor->lastname}}</h2>
                      <div class="media">
                            <div class="media-body">
                              <h5>Descripcion del Producto:<h5>
                              <h5 class="media-heading">{{$producto->descripcion}}</h5>
                            </div>
                      </div>
                      <div class="row">
                            <div class="col-md-6 col-xs-6 borde">
                                <h6>Hora: </h6>
                                <h6>Inicio: {{$producto->horaInicio}}</h6>
                                <h6>Fin: {{$producto->horaFin}}</h6>
                            </div>
                            <div class="col-md-6 col-xs-6 borde">
                                <h6>Fecha:</h6>
                                <h6>Fin: {{$producto->fechaFin}}</h6>
                            </div>
                      </div>
                  </div>
                  <div class="col-md-5 col-xs-5">
                      <h7>Zona de Reparto</h7>
                      <div id="mapas" class="control-label col-md-12" style="height:200px;"></div>
                  </div>
          </div>
          <div class="col-md-12 col-xs-12 relleno">
              <h2>Comentarios</h2> 
              <div class="col-md-12 col-xs-12 bordeado">
                  <div class="media-body">
                    @foreach($listComents as $coment)
                          <div class="form-group">
                            <label for="comment"><b>Publicado por, </b>{{$coment->name}}</label>
                            <textarea readonly class="form-control"  rows="2" cols="87" id="comment">{{$coment->comentario}}</textarea>
                          </div>
                    @endforeach
                    <form action="/guardarMensaje" method="POST">
                          <input type="hidden" name="_token" value="{{ csrf_token() }}">
                          <input type="hidden" name="idProducto" id="idProducto" value="{{$producto->idProducto}}">
                          <div class="form-group">
                            <label for="comment"><b>Publicar...</label>
                            <textarea class="form-control" rows="2" cols="87" id="comment" name="comment"></textarea>
                          </div>
                          <input type="submit" class="btn btn-primary"></input> 
                    </form>                
                  </div>
              </div>  
          </div>
          <div class="col-md-12 col-xs-12 relleno" align="center">
                  <a id="editar" class="btn btn-danger btn-lg" href="/home" role="button">Volver</a>
          </div>

        </div>
          
        </div>
          
        
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB40mKSFkIaqRI1xpZh-Z-myVr11Lhzysk&callback=initMap" async defer>
        </script>
        <script>
            var miPos;
            var marker;
            function initMap() {
                  navigator.geolocation.getCurrentPosition(
                      function (position){
                                  miPos =  {
                                  lng: {{$producto->longitud}},
                                  lat: {{$producto->latitud}}
                                  };
                                var mapa = new google.maps.Map(document.getElementById('mapas'), {
                                  zoom: 14,
                                  center: miPos
                                });       
                                     
                                marker = new google.maps.Marker({
                                  position: miPos,
                                  map: mapa,
                                  title:"Aquí se vende el producto!",
                                }); 
                      },null);
            };
        </script>
        <script>
            
                  function confirmar() {
                      var txt;
                      var r = confirm("¿Está seguro que desea realizar la compra?");
                      if (r == true) {
                          window.location.replace('http://127.0.0.1:8000/productos/{{$producto->idProducto}}/comprar');
                      }
                      
                  }
            
        </script>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

  </body>
</html>