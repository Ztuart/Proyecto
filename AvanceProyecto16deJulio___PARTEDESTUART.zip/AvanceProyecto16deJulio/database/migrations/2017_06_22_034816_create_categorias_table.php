<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCategoriasTable extends Migration
{
    public function up()
    {
        Schema::create('categorias', function (Blueprint $table) {
            $table->increments('idCategoria');
            $table->string('nombreCategoria',80);
        });

        DB::table('categorias')->insert(array('idCategoria' => '1','nombreCategoria' => 'Alimentos'));
        DB::table('categorias')->insert(array('idCategoria' => '2','nombreCategoria' => 'Inmuebles'));
        DB::table('categorias')->insert(array('idCategoria' => '3','nombreCategoria' => 'Libros y Revistas'));
        DB::table('categorias')->insert(array('idCategoria' => '4','nombreCategoria' => 'Consola y Videojuegos'));
        DB::table('categorias')->insert(array('idCategoria' => '5','nombreCategoria' => 'Instrumentos Musicales'));
        DB::table('categorias')->insert(array('idCategoria' => '6','nombreCategoria' => 'Ropa y Accesorios'));
        DB::table('categorias')->insert(array('idCategoria' => '7','nombreCategoria' => 'Servicios'));
        DB::table('categorias')->insert(array('idCategoria' => '8','nombreCategoria' => 'Animales y Mascotas'));
        DB::table('categorias')->insert(array('idCategoria' => '9','nombreCategoria' => 'Vehículos'));         
        DB::table('categorias')->insert(array('idCategoria' => '10','nombreCategoria' => 'Otros'));                                 
    }

    public function down()
    {
        Schema::dropIfExists('categorias');
    }
}
