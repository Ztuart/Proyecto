<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {

            $table->increments('id');
            $table->integer('idRol')->default('1'); //Publico1;Administrador2
            $table->string('name',80);
            $table->string('lastname',80);
            $table->string('email',80)->unique();
            $table->string('password',255);
            $table->string('alias',80);
            $table->smallInteger('estado')->default('0'); //Habilitado1; Deshabilitado0
            $table->integer('numReports')->default('0');
            $table->string('hash',256);
            $table->rememberToken();
            $table->timestamps();
        });

        DB::table('users')->insert(
            array(
                'idRol' => '2',
                'name' => 'Admin',
                'lastname' => 'Ford',
                'email' => 'admin@pucp.pe',
                'password' => '$2y$10$ViajIsY3Nb6LcW/B7PH4luoOJAaNWsTQgTuSxY/eWUTqoDjRKV9H6',   
                'alias' => 'Adm',
                'estado' => 1,
                'numReports' => 0,         
                'hash' => '$2y$10$zMG1rU5nxSeQHm/VkXp1le3la9PHDlcVPk58uqGWfk6I.MHVMXySK'                                       
            )
        );
        DB::table('users')->insert(
            array(
                'name' => 'User',
                'lastname' => 'Lamb',
                'email' => 'user@pucp.pe',
                'password' => '$2y$10$wmpGkpnvR0iUZ4wdFRAlTeOuFYWNSaTM1UNXN0k3D5pYgsIE8z/hS',   
                'alias' => 'Eddy',
                'estado' => 1,
                'numReports' => 0,         
                'hash' => '$2y$10$VDGhOFoowPrWRqdQeLWOTe1RDoypplhUxYiS92lMqioqk8D2dmgcK'                                       
            )
        );        
    }

    public function down()
    {
        Schema::dropIfExists('users');
    }
}
