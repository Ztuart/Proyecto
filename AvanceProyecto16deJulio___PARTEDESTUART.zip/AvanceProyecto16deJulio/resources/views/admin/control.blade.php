<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>LOGIN</title>        
        <link rel="stylesheet" href="">
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    
    </head>
    <body>
     
     <div class="container">
      <div class="col-xs-12 col-md-11 col-md-offset-10 col-xs-offset-8" >
                        <div ><b>PUCP Delivery</b></div>
                        <div><a href="/home" ><span><h4>Ir a home</h4></span></a><br></div>
      </div>
     <div class="jumbotron col-xs-12 col-md-12" style="border-style: ridge; padding-top:15px;padding-bottom:15px; ">
      <div class="form-group">
          <h2 class="col-xs-10 col-md-10" ><strong>Bienvenido a la búsqueda de clientes!</strong></h2>
          <a type="button" href="/panelAdmin" class="btn btn-primary col-sm-2 col-md-2">Mostrar todos</a> 
      </div>
        <form class="form-horizontal col-xs-12 col-md-12" method="POST" action="/panelAdmin/buscar">

            <div class="form-group ">
              <label for="email">Ingrese el correo</label>
              <input type="hidden" name="_token" value="{{ csrf_token() }}">
              <input type="email" class="form-control" id="email" name="email" placeholder="Correo">
              <button type="submit" class="btn btn-primary col-sm-2 col-md-2" >Buscar</button> 
            </div>
        </form>
        
        <form class="form-horizontal col-xs-12 col-md-12" method="GET" action="/panelAdmin/buscar">
            <div class="form-group">
              <button type="submit" class="btn btn-danger">Ver todas las personas reportadas</button> 
              <label class="col-md-11" style="padding-left:0px;">*Se recomienda cambiar el estado de un cliente cuando supera los 5 reportes*</label>
            </div>
        </form>
       
      </div>
     <table class="table table-bordered col-xs-12 col-md-12">
    <thead>
      <tr>
        <th>Nombre</th>
        <th>Apellido</th>
        <th>Correo</th>
        <th>Reportes</th>
        <th>Estado</th>
      </tr>
    </thead>
    
    <tbody>
        @foreach($usuarios as $usuario)
        <tr>
         
              <td>{{$usuario->name}}</td>
              <td>{{$usuario->lastname}}</td>
              <td>{{$usuario->email}}</td>
              <td>{{$usuario->numReports}}</td>
              <td>{{$usuario->estado}}</td>
              <td> 
                <a href="/panelAdmin/cambiarEstado/{{$usuario->id}}">Cambiar Estado</a>
              </td> 
         </tr>
        @endforeach
    </tbody>
    
  </table>
     </div>  
    </body>
</html>