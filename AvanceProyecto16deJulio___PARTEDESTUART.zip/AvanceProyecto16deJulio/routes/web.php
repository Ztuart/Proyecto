<?php
//Sesiones en PHP
//$request->session()->put('correo', $user->email);
//$request->session()->put('id', $user->id);
//$request->session()->put('idRol', $user->idRol);
// Autenticatión
Auth::routes();
Route::get('/',  'Auth\LoginController@log');
Route::get('/validarCorreo', 'EmailConfirmController@dirigirCorreo');
Route::post('/validarCorreo', 'EmailConfirmController@validarCorreo');
//Panel Administrador
Route::get('/admin', 'Admin\AdminController@mainPrincipal');
Route::get('/panelAdmin', 'Admin\AdminController@panelControl');
Route::post('/panelAdmin/buscar', 'Admin\AdminController@buscarPorCorreo');
Route::get('/panelAdmin/buscar', 'Admin\AdminController@buscarReportados');
Route::get('/panelAdmin/cambiarEstado/{id}', 'Admin\AdminController@cambiarEstado');
//Panel principal
Route::get('/home', 'Home\HomeController@mainPrincipal');
Route::get('/misProductos', 'Home\HomeController@verMisProductos');
Route::get('/misProductos/visibilidad/{idProducto}', 'Home\HomeController@visibilidadProductos');
//Editar Mi Info
Route::get('/info', 'Auth\MyInfoController@mostrarFormInfo');
Route::post('/info', 'Auth\MyInfoController@saveNewInfo');

//Productos
Route::get('/productos/create', 'Products\ProductsController@crearProducto');
Route::post('/productos/save', 'Products\ProductsController@guardarProducto');
Route::get('/productos/{idProducto}','Products\ProductsController@verProducto' );
Route::post('/productos/{idProducto}/edit','Products\ProductsController@saveEdit' );




//Imágenes
Route::get('/public/{archivo}', function ($archivo) {
    $public_path = public_path();
     if (Storage::exists('/public/'.$archivo))
     {
       return response()->download($public_path.'/storage'.'/public/'.$archivo);
     }
     abort(404);
});
















/*
// Authentication Routes...
$this->get('login', 'Auth\LoginController@showLoginForm')->name('login');    YA ESTA
$this->post('login', 'Auth\LoginController@login');    YA ESTA
$this->post('logout', 'Auth\LoginController@logout')->name('logout');

// Registration Routes...
$this->get('register', 'Auth\RegisterController@showRegistrationForm')->name('register');   YA ESTA
$this->post('register', 'Auth\RegisterController@register');

// Password Reset Routes...
$this->get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm');
$this->post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail');

$this->get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm');
$this->post('password/reset', 'Auth\ResetPasswordController@reset');*/