<!--MockUp Generar Producto a vender-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Genere su Producto</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
      <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body >
      <div class="container ">

          <div class="row" >
            <div class="col-md-9">
              <h1 class="titulo">DETALLE PRODUCTO</h1>
            </div>
          </div>

        <form action="/action_page.php">

        <div class="jumbotron">

          <div class="row">
            <div class="col">
                  <h2><label>Bicicleta </label></h2> 
            </div>
            <div class="col">
                  <a id="editar" class="btn btn-success " href="..." role="button">Realizar Compra</a> 
            </div>
          </div>
          <br>
          <div class="row">
            <div class="col">
                  <img src="https://www.decathlon.es/media/832/8321326/big_0f915e43-065f-4e67-95a9-dfce13aa146d.jpg" width="250" height="250">
            </div>
            <div class="col">
                <div class="row">
                  <h2><label>Stuart Cabrera </label></h2>
                </div>
                <div class="row">
                  <div class="media">
                    <div class="media-body">
                      <h3><span>Descripcion del Producto:</span><h3>
                      <h5 class="media-heading">Aqui se obtiene la descripcion del producto de la BD</h5>
                      
                    </div>
                  </div>
                </div>
                <br>
                <div class="row">
                  <div class="col">
                    <h3>Hora: </h3>
                    <h4>Inicio:</h4>
                    <h4>Fin:</h4>
                  </div>
                  <div class="col">
                    <h3>Fecha:</h3>
                    <h4>Fin:</h4>
                  </div>
                </div>
                   
            </div>
            <div class="col">
                Espacio para el mapa de zona de reparto
            </div>
          </div>
          <br>
          <div class="row">
             <h2>Comentarios</h2> 
          </div>
          <div class="row">
            
          </div>
          <div class="row">
            <div class="media">
              <div class="media-body">
                <h4 class="media-heading">Aqui se escriben los comentarios del estuar sobre el producto, en esta parte ira el  para jalar todos los coments  de la BD. También usaremos el pagination</h4>
                
              </div>
            </div>
          </div>
             
          <div class="row justify-content-md-center">
              <div >
                <a id="editar" class="btn btn-success col-md-offset-5" href="..." role="button"><span class="glyphicon glyphicon-thumbs-up"></span>Me gustó mucho este producto</a>
              </div>
              <div>
                <a id="editar" class="btn btn-primary col-md-offset-5" href="..." role="button">Enviar comentarios</a>
              </div>
                
                
            </div>  

            <div class="row justify-content-md-center">
                <a id="editar" class="btn btn-danger col-md-offset-5" href="..." role="button">Volver</a>
                  
          </div>
          </div>
          


        </form>
        </div>
          
        <style type="text/css">
          h1{
            font-size: 3.1em;
            padding-left: 80px;
            margin-bottom: 40px;         
          }
          
          
          #editar{
            
            margin-top: 10px;
              
            padding: 10px;
            font-size: 2.0em;
            
          }
          .titulo{
            margin-top: 30px;
            padding-left: 10px;
          }
          .jumbotron{
            background-color: #ecb535 ;
          }
          html body{
            background-image: url("http://dissenyaweb.com/blog/diseno_web/wp-content/uploads/christian-background-loops.jpg");
            
          }
        </style>
    

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

  </body>
</html>