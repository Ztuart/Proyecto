
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Productos Vendidos</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
      <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  </head>
  <body>
      <div class="container">
        <div class="page-header"> 
            <span class="col-md-8  col-md-offset-10"><h3>PUCP Delivery</h3></span>

        </div>        
          <div class="jumbotron jumbotron-fluid">
            <div class="row">  
                <label class= "col-md-8"><h2>Mi Lista de productos:</h2></label>
                <a id ="regresar" class="btn btn-success" href="/home" role="button">Regresar</a><br>
            </div>
            <br> 
             <?php $__currentLoopData = $misproductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">             
                    <div class="col-md-3">
                <img src="<?php echo e($producto->imagen); ?>" class="image media-object" alt="image" width="150px" height="120px">
                    </div>                    
                    <div class="col-md-4">
                          <h5><?php echo e($producto->nombreProducto); ?></h5>
                          <span class="text">
                              <?php echo e($producto->descripcion); ?>

                          </span>
                          
                    </div> 
                      <div><a id="botonhabilitar" class="btn btn-primary col-md-8" href="/misProductos/visibilidad/<?php echo e($producto->idProducto); ?>" role="button"><?php echo e($producto->visibilidad==1?"Deshabilitar":"Habilitar"); ?></a><br></div>
                      <div><a id="botondeshabilitar" class="btn btn-primary col-md-10" href="/productos/<?php echo e($producto->idProducto); ?>" role="button">Editar</a><br></div>                                          
            </div>
            <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                            
        </div>
              
            
      </div>
      <style type="text/css">
         h1{
            font-size: 3.1em;
            margin-left: 30px;
         }
         h2{
          font-size: 2.5em;
         }
         .jumbotron{
            padding-top: 30px;
            margin-top: 20px;
            margin-left: 30px;
            padding-left: 80px;
            background-color: rgb(228,210,143); 
         }
         #botonhabilitar{
          margin-left: 50px;
          margin-top: 30px;
          background-color: rgb(4,79,123);
         }
         #botondeshabilitar{
          margin-left: 20px;
          margin-top: 30px;
          background-color: rgb(4,79,123);
         }
         #regresar{
          padding-top: 18px;
          margin-left: 100px;
          background-color: rgb(61,119,68);
         
         }
      </style>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
 
  </body>
</html>