<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use App\Categoria;
use App\Producto;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function mainPrincipal()
    {
    	$categorias = Categoria::all();
        $productos = Producto::where('visibilidad', '=', 1)->paginate(4);
    	return view('home.main', compact('categorias','productos'));
    }
    public function verMisProductos(Request $request)
    {
    	$miID = $request->session()->get('id');
    	$misproductos = DB::table('productos')->where('idVendedor', '=', $miID)->get();
    	return view('home.misproductos', compact('misproductos'));
    }
    public function visibilidadProductos($idProducto)
    {
    	$producto = Producto::find($idProducto);
    	if($producto->visibilidad == 1)
    	{
    		$producto->visibilidad = 0;
    	}else
    	{
    		$producto->visibilidad = 1;
    	}

    	$producto->save();
    	return redirect('/misProductos');
    }

}
