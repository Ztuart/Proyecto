<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\User;

class MyInfoController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function mostrarFormInfo(Request $request)
    {
    	$correo = $request->session()->get('correo');
        $user = DB::table('users')->where([['email','=', $correo]])->first();      
    	return view('users.editarInfo',compact('user'));
    }

    public function saveNewInfo(Request $request)
    {
    	$user= User::find($request->session()->get('id'));
    	$user->name = $request->input('name');
    	$user->lastname = $request->input('lastname');
    	$user->alias = $request->input('alias');   
    	$user->save(); 	 
    	return redirect('/home');   	
    }

}
