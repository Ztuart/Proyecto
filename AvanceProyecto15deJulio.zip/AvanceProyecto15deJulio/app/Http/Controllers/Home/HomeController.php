<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Categoria;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function mainPrincipal(){
    	$categorias = Categoria::all();
    	return view('home.main', compact('categorias'));
    }

}
