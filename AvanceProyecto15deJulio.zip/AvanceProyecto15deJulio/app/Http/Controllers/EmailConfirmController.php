<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;

class EmailConfirmController extends Controller
{
    public function dirigirCorreo()
    {
    	$val = $_GET['acc'];
        return view('emails.confirm', compact('val'));
    }
    public function validarCorreo(Request $request)
    {
        $hash = $request->input('val');
        DB::table('users')->where('hash', $hash)->update(['estado' => 1]);
        return redirect('/');
    }
}
