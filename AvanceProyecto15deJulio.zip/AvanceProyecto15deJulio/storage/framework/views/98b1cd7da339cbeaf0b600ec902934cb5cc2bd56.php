<!--MockUp Generar Producto a vender-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Editar Información</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
      <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body >
      <div class="container ">

          <div class="row" >
            <div class="col-md-9">
              <h1 class="titulo">EDITAR INFORMACIÓN</h1>
            </div>
          </div>

        <form action="/info" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="jumbotron">
            <div class="row">
                <div class="col">
                  <b><label>Nombre: </label></b> 
                  <input type="text" class="form-control" name = "name" id="name" value="<?php echo e($user->name); ?>">  
                </div>
                <div class="col">
                  <b><label>Apellido: </label> </b>
                  <input type="text" class="form-control" name = "lastname" id="lastname" value="<?php echo e($user->lastname); ?>">
                </div>

                <div class="col">
                  <b><label>Alias: </label></b>                 
                    <input type="text" class="form-control" name = "alias" id="alias" value="<?php echo e($user->alias); ?>">
                </div>
                    

                  
            </div>
            <div class="row justify-content-md-center">
                <button type="submit" id="editar" class="btn btn-success col-md-offset-5">Guardar</button>
            </div>  
          </div>
        </form>



        </div>
          
        <style type="text/css">
          h1{
            font-size: 3.1em;
            padding-left: 80px;
            margin-bottom: 40px;         
          }
          
          
          #editar{
            
            margin-top: 10px;
              
            padding: 10px;
            font-size: 2.0em;
            
          }
          .titulo{
            margin-top: 30px;
            padding-left: 10px;
          }
          .jumbotron{
            background-color: #ecb535 ;
          }
          html body{
            background-image: url("http://dissenyaweb.com/blog/diseno_web/wp-content/uploads/christian-background-loops.jpg");
            
          }
        </style>
    

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

  </body>
</html>